package com.AddHashtags.PopularTags;

public class SubjectItem {
    public String tagName;
    public boolean check;

    public SubjectItem(String tagName, boolean check) {
        this.tagName = tagName;
        this.check = check;
    }
}
