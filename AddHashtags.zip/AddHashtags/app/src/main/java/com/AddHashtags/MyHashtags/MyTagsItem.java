package com.AddHashtags.MyHashtags;

public class MyTagsItem {
    public String tagName;
    public boolean check;

    public MyTagsItem(String tagName, boolean check) {
        this.tagName = tagName;
        this.check = check;
    }
}
